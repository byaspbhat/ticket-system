package com.walmart.interview.ticket.entity;

public enum SeatStatus { 
    BOOKED, 
    EMPTY,
    HOLD;
	
} 