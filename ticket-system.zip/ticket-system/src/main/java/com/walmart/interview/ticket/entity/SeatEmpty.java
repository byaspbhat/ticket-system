package com.walmart.interview.ticket.entity;

public class SeatEmpty extends Seat {
	
	public SeatEmpty(String id) {
		this.id=id;
	}
	

}
