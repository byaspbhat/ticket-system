TicketSystemApplication will start the app.
it takes input as number of seat and email and book the seat.


Coustomer is a runnable task, which will book the ticket.

seat are arranged in concurrent hash map.
